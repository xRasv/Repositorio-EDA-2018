/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio3;

/**
 *
 * @author ximena
 */
public class ArbolAVL {
    private NodoArbolAVL raiz; 
    
    public ArbolAVL (){
        raiz = null;
    }
    
    public NodoArbolAVL obtenerRaiz(){
        return raiz;
    }
    
    //BUSQUEDA DE NODOS 
    public NodoArbolAVL buscar(int d, NodoArbolAVL r){
        if (raiz == null){
            return null;
        }
        else if (r.dato == d){
            return r;
        }
        else if (r.dato < d){
            return buscar(d,r.hijoDerecho);
        }
        else{
            return buscar(d,r.hijoIzquierdo);
        }
    }
    
    //Factor de equilibrio 
    public int obtenerFE (NodoArbolAVL x){
        if(x==null){
            return -1;
        }
        else
        {
            return x.fe;
        }
    }
    
    //RSI
    public NodoArbolAVL rotacionIzquierda(NodoArbolAVL c){
        NodoArbolAVL auxiliar = c.hijoIzquierdo;
        c.hijoIzquierdo = auxiliar.hijoDerecho;
        auxiliar.hijoDerecho=c;
        c.fe = Math.max(obtenerFE(c.hijoIzquierdo), obtenerFE(c.hijoDerecho))+1; 
        auxiliar.fe = Math.max(obtenerFE(auxiliar.hijoIzquierdo), obtenerFE(auxiliar.hijoDerecho))+1;
        
        return auxiliar; 
    }
    
    //RSD
    public NodoArbolAVL rotacionDerecha(NodoArbolAVL c){
        NodoArbolAVL auxiliar = c.hijoDerecho;
        c.hijoDerecho = auxiliar.hijoIzquierdo;
        auxiliar.hijoIzquierdo=c;
        c.fe = Math.max(obtenerFE(c.hijoDerecho), obtenerFE(c.hijoIzquierdo))+1; 
        auxiliar.fe = Math.max(obtenerFE(auxiliar.hijoDerecho), obtenerFE(auxiliar.hijoIzquierdo))+1;
        
        return auxiliar; 
    }
    
    //RDD
    public NodoArbolAVL rotacionDobleIzquierda(NodoArbolAVL c){
        NodoArbolAVL temporal;
        c.hijoIzquierdo = rotacionDerecha(c.hijoIzquierdo);
        temporal = rotacionIzquierda(c);
        return temporal;
    }
    
    //RDI
    public NodoArbolAVL rotacionDobleDerecha(NodoArbolAVL c){
        NodoArbolAVL temporal;
        c.hijoDerecho = rotacionIzquierda(c.hijoIzquierdo);
        temporal = rotacionDerecha(c);
        return temporal; 
    }
    
    //INSERTAR DATOS BALANCEADOS
    public NodoArbolAVL insertarBalance(NodoArbolAVL nuevo, NodoArbolAVL subArbol){
        NodoArbolAVL nuevoPadre = subArbol;
        if(nuevo.dato < subArbol.dato){
            if(subArbol.hijoIzquierdo == null){
                subArbol.hijoIzquierdo = nuevo;
            }
            
            else{
                subArbol.hijoIzquierdo=insertarBalance(nuevo, subArbol.hijoIzquierdo);
                
                if((obtenerFE(subArbol.hijoIzquierdo)) - obtenerFE(subArbol.hijoDerecho) == 2){
                    
                    if(nuevo.dato < subArbol.hijoIzquierdo.dato){
                        nuevoPadre = rotacionIzquierda(subArbol);
                    }
                    
                    else{
                        nuevoPadre = rotacionDobleIzquierda(subArbol);
                    }
                }
            }
        }
        else if (nuevo.dato > subArbol.dato){
           if(subArbol.hijoDerecho==null){
               subArbol.hijoDerecho = nuevo;
           }
           else{
               subArbol.hijoDerecho = insertarBalance(nuevo, subArbol.hijoDerecho);
               if((obtenerFE(subArbol.hijoDerecho)) - obtenerFE(subArbol.hijoIzquierdo) == 2){
                   if(nuevo.dato > subArbol.hijoDerecho.dato){
                       nuevoPadre =  rotacionDerecha(subArbol);
                   }
                   else{
                       nuevoPadre = rotacionDobleDerecha(subArbol);
                   }
               }
           }
        }else{
            System.out.println("Nodo esta dublicado");
        }
        
        //Actulizando FE 
        if ((subArbol.hijoIzquierdo==null) && (subArbol.hijoDerecho != null)){
            subArbol.fe =  subArbol.hijoDerecho.fe+1; 
        }
        else if ((subArbol.hijoDerecho ==null) && (subArbol.hijoIzquierdo != null)){
            subArbol.fe = subArbol.hijoIzquierdo.fe+1;
        }
        else{
            subArbol.fe = Math.max(obtenerFE(subArbol.hijoIzquierdo), obtenerFE(subArbol.hijoDerecho)) +1 ;
        }
        
        return nuevoPadre;
    }
    
    //insetar datos 
    public void insertar(int d){
        NodoArbolAVL nuevo = new NodoArbolAVL(d);
        if(raiz ==  null){
            raiz =  nuevo;
        }
        else{
            raiz = insertarBalance(nuevo, raiz);
        }
    }
    
    //ORDENAMIENTO
    //PREORDEN
    public void preOrden (NodoArbolAVL r){
        if(r!=null){
            System.out.print(r.dato + ", ");
            preOrden(r.hijoIzquierdo);
            preOrden(r.hijoDerecho);
        }
    }
    //POSTORDEN
    public void postOrden (NodoArbolAVL r){
        if(r!=null){
            postOrden(r.hijoIzquierdo);
            postOrden(r.hijoDerecho);
            System.out.print(r.dato + ", ");
        }
    }
    //INORDEN
    public void inOrden (NodoArbolAVL r){
        if(r!=null){
            inOrden(r.hijoIzquierdo);
            System.out.print(r.dato + ", ");
            inOrden(r.hijoDerecho);
        }
    }
}
